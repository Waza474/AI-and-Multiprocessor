#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <mpi.h>
#include <time.h>
#include <sys/time.h>
#define SHIFT_ROW 0
#define SHIFT_COL 1
#define DISP 1
#include <unistd.h>
#include <pthread.h>
#define MAXNODE 99
void timer()
{
    time_t start;
    start = time((time_t*)NULL);
    time_t now;
    now = time((time_t*)NULL);
    while ((now - start) <= 2)
    {
        now = time((time_t*)NULL);
    }
}

int get_temp(int range)
{

    return (rand() % range);
}

typedef struct Info
{
    time_t time;
    struct timeval timevalue ;
    int temprature ;
    int count ;
    int rank ;
    int nei_temp[4];
    int adj[4];
} Info;

int iter_max = 19;
int RANGE = 100;
int THREAD = 80;
int SAME_STD = 3;
int nrows = 0, ncols = 0;
int Infrared_value[MAXNODE];
time_t Infrared_time[MAXNODE];
void *get_infrared()
{
	//getting random temperatures and the time when got it and store them in the n*m array
    while (1)
    {

        for (int i = 0; i < nrows * ncols; i++)
        {
            Infrared_value[i] = get_temp(RANGE);
            Infrared_time[i] = time((time_t*)NULL);
        }
        sleep(2);

    }
}


void get_infrared_test()
{
    timer();
    for (int i = 0; i < nrows * ncols; i++)
    {
        Infrared_value[i] = get_temp(RANGE);
        Infrared_time[i] = time((time_t*)NULL);
    }

}

int TimeToString(char* strDateStr, const time_t* timeData)
{
	//convert time to string
    char chTmp[25];
    memset(chTmp, 0, sizeof(chTmp));

    struct tm* p;
    p = localtime(timeData);

    p->tm_year = p->tm_year + 1900;

    p->tm_mon = p->tm_mon + 1;


    snprintf(chTmp, sizeof(chTmp), "%04d-%02d-%02d  %d:%d:%d",
             p->tm_year, p->tm_mon, p->tm_mday,p->tm_hour,p->tm_min, p->tm_sec);

    memcpy(strDateStr, chTmp, 25);
    return 0;
}

//write_log(infos[i], log_file, iter, recved_num[i], Infrared_value[i], Infrared_time[i], recved_time[i] );

void write_log(Info info, FILE * file, int iter, int revced_num,int inf_value, time_t inf_time , struct timeval recvtime)
{
	//write results to log file.
    time_t logged;
    logged = time((time_t*)NULL);
    
    //printf("\tR: %d 1. %ld 2.%ld 3.%ld\n",info.rank, recvtime, info.time, recvtime - info.time);
    //time_t time_spend = recvtime - info.time;
    long double time_spend = (recvtime.tv_sec*1000000 + recvtime.tv_usec) - (info.timevalue.tv_sec*1000000 + info.timevalue.tv_usec);
    time_spend = time_spend/1000000;
    
    char* logged_time = (char*)malloc(25);
    char* infr_time = (char*)malloc(25);
    char* alert_time = (char*)malloc(25);
    //printf("\t1. %ld 2. %ld 3. %ld\n",logged, inf_time, info.time);
    TimeToString(logged_time, &logged);
    TimeToString(infr_time, &inf_time);
    TimeToString(alert_time, &info.time);
    char *type = (char*)malloc(6);
    if (inf_value == info.temprature)
    {
        memcpy(type, "True", 5);
    }
    else
    {
        memcpy(type, "False", 6);
    }



    fprintf(file, "\n------------------------\n");
    fprintf(file, "iteration : %d\n", iter);
    fprintf(file, "Logged time :   %s\n", logged_time);
    fprintf(file, "Alert Reported time :   %s\n", alert_time);
    fprintf(file, "Alert Type : %s\n", type);

    fprintf(file, "\n");
    fprintf(file, "Reporting Node\t\t\t\tCoord\t\tTemp\n");
    fprintf(file, "%3d\t\t\t\t\t\t\t(%d,%d)\t\t%3d\n", info.rank, info.rank / ncols, info.rank % ncols, info.temprature);
    fprintf(file, "Adjacent Nodes Temp\t\t\tCoord\t\tTemp\n");
    for (int i = 0; i < 4; i++)
    {
        if (info.adj[i] >= 0 )
        {
            fprintf(file, "%3d\t\t\t\t\t\t\t(%d,%d)\t\t%3d\n", info.adj[i], info.adj[i] / ncols, info.adj[i] % ncols, info.nei_temp[i]);
        }
    }
    fprintf(file, "\n");
    fprintf(file, "Infrared Satellite Reporting Time %s\n", infr_time);
    fprintf(file, "Infrared Satellite Reporting (Celsius) : %d\n", inf_value);
    fprintf(file, "Infrared Satellite Reporting Coord : (%d,%d)\n", info.rank / ncols, info.rank % ncols);
    fprintf(file, "\n");

    fprintf(file, "Communication Time(Seconds) : %Lf\n", time_spend);
    fprintf(file, "Total Messages send between reporting node and base station: %d\n", revced_num);
    fprintf(file, "Number of adjacent matches to reporting node: %d\n", info.count);
    fprintf(file, "------------------------\n");

    fflush(file);
    
    free(logged_time);
    free(infr_time);
    free(alert_time);
    free(type);

}

int main(int argc, char* argv[]) {
    

    int ndims = 2, size, my_rank, reorder, my_cart_rank, ierr;
    int top, bottom;
    int left, right;
    MPI_Comm comm2D;
    int* dims = (int*)malloc(sizeof(int) * ndims);
    int* coord = (int*)malloc(sizeof(int) * ndims);
    int* wrap_around = (int*)malloc(sizeof(int) * ndims);

    /* start up initial MPI environment */
    int provided;
    MPI_Init_thread(&argc, &argv, MPI_THREAD_MULTIPLE, &provided);
    if (provided < MPI_THREAD_MULTIPLE)
    {
        printf("Error: the MPI library doesn't provide the required thread level\n");
        MPI_Abort(MPI_COMM_WORLD, 0);
    }
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    /* process command line arguments*/
    if (argc == 3) {
        nrows = atoi(argv[1]);
        ncols = atoi(argv[2]);
        dims[0] = nrows;
        dims[1] = ncols; /* number of columns */
        //if ((nrows * ncols) != size) {
        //	if (my_rank == 0) printf("ERROR: nrows*ncols)=%d *% d = % d != % d\n", nrows, ncols, nrows*ncols,size);
        //		MPI_Finalize();
        //	return 0;
        //}
    }

    /************************************************************
    */
    /* create cartesian topology for processes */
    /************************************************************
    */
	
	// split two types of nodes, color 0 represent base station, color 1 represent sensor nodes
    int color;
    if (my_rank == 0)
    {
        color = 0;
    }
    else
    {
        color = 1;
    }
    MPI_Comm newcomm;
    MPI_Comm_split(MPI_COMM_WORLD, color, my_rank, &newcomm);
    MPI_Datatype INFO;


    // for all sensor nodes 
    if (my_rank!=0)
    {
        //printf("\tMYRANK: %d\n",my_rank);
        MPI_Dims_create(size-1, ndims, dims);
        wrap_around[0] = wrap_around[1] = 0;
        reorder = 1;

        ierr = 0;
        ierr = MPI_Cart_create(newcomm, ndims, dims,
                               wrap_around, reorder, &comm2D);
        int rank2d;
        MPI_Comm_rank(newcomm, &rank2d);
        //if (ierr != 0) printf("ERROR[%d] creating CART\n", ierr);
        /* find my coordinates in the cartesian communicator group */
        MPI_Cart_coords(comm2D, my_rank-1, ndims, coord);
        /* use my cartesian coordinates to find my rank in cartesian
        group*/
        MPI_Cart_rank(comm2D, coord, &my_cart_rank);
        /* get my neighbors; axis is coordinate dimension of shift */
        /* axis=0 ==> shift along the rows: P[my_row-1]: P[me] :
        P[my_row+1] */
        /* axis=1 ==> shift along the columns P[my_col-1]: P[me] :
        P[my_col+1] */
        MPI_Cart_shift(comm2D, SHIFT_ROW, DISP, &top, &bottom
        );
        MPI_Cart_shift(comm2D, SHIFT_COL, DISP, &left, &right
        );
        top++;
        bottom++;
        left++;
        right++;
        int neibor[4] = { left,right,top,bottom };
        int iter = 0;
        //srand((int)my_rank);
        srand(time(0) * (int)my_rank);
        while (1)

        {
            int temp[4] = { 0,0,0,0 };
            int recv_flags[4] = {0,0,0,0}, check_flag = 0, sent_flag =0 ;

            MPI_Bcast(&iter, 1, MPI_INT, 0, MPI_COMM_WORLD);

            MPI_Barrier(MPI_COMM_WORLD);
			
			//when iteration number exceeding the max iteration, end
            if (iter > iter_max)
            {
                MPI_Finalize();
                break;
            }
            else
            {
                time_t start;
                start = time((time_t*)NULL);
                time_t now;
                now = time((time_t*)NULL);
                int temprature = 0;
                MPI_Status status_receive_no_fire[4], status_send_no_fire[4];
                MPI_Request request_send_no_fire[4], request_receive_no_fire[4];
                int flag[4] = {0,0,0,0};
				
				//loop unitil used time is greater than a particular period of time, in here the time gap is set to be 2 seconds
                while ((now - start) <= 2)
                {
                    temprature = get_temp(RANGE);
                    
					//when temperature<threshold, no need to request temperatures from other nodes, just waiting for requests from other nodes

                    if (temprature < THREAD)
                    {
                        //printf("\t! A %d B %d !\n\t\tLESS\n", temprature, THREAD);
                        for (int i = 0; i < 4; i++)
                        {
                            if (neibor[i] > 0 && flag[i] == 0 )
                            {
                                MPI_Iprobe(neibor[i], iter, MPI_COMM_WORLD, &flag[i],&status_receive_no_fire[i]);
                                if (flag[i] == 1)
                                {
                                    MPI_Irecv(&temp[i], 1, MPI_INT, neibor[i], iter, MPI_COMM_WORLD, &request_receive_no_fire[i]);
                                    recv_flags[i] = 1;
                                    fflush(stdout);
                                    MPI_Isend(&temprature, 1, MPI_INT, neibor[i], iter, MPI_COMM_WORLD, &request_send_no_fire[i]);
                                }
                            }
                        }
                        now = time((time_t*)NULL);
                    }
					
					//when temperature>threshold, request temperatures data from neighbour nodes.
        
                    if (temprature >= THREAD && sent_flag == 0)
                    {
                        //printf("\t! A %d B %d !\n\t\tMORE\n", temprature, THREAD);
                        MPI_Request request_send[4], request_receive[4];
                        MPI_Status status_send[4], status_receive[4];

                        for (int i = 0; i < 4; i++)
                        {
                            if (neibor[i] > 0 && recv_flags[i] == 0)
                            {
                                MPI_Isend(&temprature, 1, MPI_INT, neibor[i], iter, MPI_COMM_WORLD, &request_send[i]);
                            }
                        }

                        for (int i = 0; i < 4; i++)
                        {
                            if (neibor[i] > 0 && recv_flags[i] == 0)
                            {
                                MPI_Irecv(&temp[i], 1, MPI_INT, neibor[i], iter, MPI_COMM_WORLD, &request_receive[i]);
                            }
                        }


                        for (int i = 0; i < 4; i++)
                        {
                            if (neibor[i] > 0 && recv_flags[i] == 0)
                            {
                                MPI_Wait(&request_receive[i], &status_receive[i]);
                            }
                        }


                        if (temprature >= THREAD)
                        {
                            //same_count in here refer to the number of times that difference between received temp and it's own temp is less or equa to 3
                            int same_count = 0;
                            for (int i = 0; i < 4; i++)
                            {
                                //printf("\n%d - %d = %d\n",temp[i], temprature, temp[i] -temprature);
                                if ( (temp[i] - temprature) <= 3   && (temp[i] - temprature) >= (-3))
                                {
                                    same_count++;
                                }
                                //printf("\t0: %d,  1: %d,  2: %d,  3: %d   Count: %d\n",temp[0],temp[1],temp[2],temp[3],same_count);

                            }
                            if (same_count >= 2)
                            {
								//if more than 2 neighbour nodes got the "same" temperatures as it's own, send alert to base station
                                Info warning_info;
                                for (int i = 0; i < 4; i++)
                                {
                                    warning_info.nei_temp[i] = temp[i];
                                    warning_info.adj[i] = neibor[i]-1;
                                }
                                warning_info.count = same_count;
                                warning_info.rank = my_cart_rank;
                                warning_info.temprature = temprature;
                                warning_info.time = time((time_t*)NULL);
                                gettimeofday(&warning_info.timevalue, NULL);
                                //printf("\tR:%d FT: %ld\n", warning_info.rank, warning_info.time);
                                MPI_Request send_to_root;
                                MPI_Isend(&warning_info, sizeof(Info) / 4, MPI_INT, 0, iter, MPI_COMM_WORLD, &send_to_root);
                            }
                        }
                        break;

                    }
                }
                MPI_Barrier(MPI_COMM_WORLD);
            }
        }






        //printf("Global rank: %d. Cart rank: %d. Coord: (%d, %d).Left: % d.Right : % d.Top : % d.Bottom : % d\n", my_rank, my_cart_rank, coord[0], coord[1], left, right, top, bottom);
        //fflush(stdout);
        //MPI_Comm_free(&comm2D);
    }
    else
    {
		
        //for base station only (my_rank = 0)
        int iter = 0;
        FILE *log_file = fopen("log.txt", "w+");
        fprintf(log_file, "start\n");
        fflush(stdout);
        int* recved_num = (int*)malloc(sizeof(int) * ncols * nrows);
        memset(recved_num, 0, sizeof(int)* ncols* nrows);

        pthread_t th;
        int ret;

        int *thread_ret = NULL;
        ret = pthread_create( &th, NULL, get_infrared, NULL );
        if( ret != 0 ){
            printf( "Create thread error!\n");
            return -1;
        }
        while (1)
        {
            printf("bcast�� new iteration start iter = %d\n", iter);
            fflush(stdout);
            MPI_Bcast(&iter, 1, MPI_INT, 0, MPI_COMM_WORLD);
            MPI_Barrier(MPI_COMM_WORLD);
			
			//similar as sensor nodes, if iteration number exceed the maximum, end
            if (iter > iter_max)
            {
                MPI_Finalize();
                break;
            }
            time_t start;
            start = time((time_t*)NULL);
            time_t now;
            now = time((time_t*)NULL);
            MPI_Request request_send[4], request_receive[4];
            MPI_Status status;
            int* recved = (int*)malloc(sizeof(int) * ncols * nrows);
            memset(recved, 0, sizeof(int)* ncols* nrows);
            //time_t* recved_time = (time_t*)malloc(sizeof(time_t) * ncols * nrows);
            //struct timeval *recved_time = (struct timeval *)malloc(sizeof(struct timeval*) * ncols * nrows);
            struct timeval recved_time[ncols * nrows];
            memset(recved, 0, sizeof(int)* ncols* nrows);
            Info* infos = (Info*)malloc(sizeof(Info) * ncols * nrows);
            
            //get_infrared_test();
			
			// loop unitil used time is greater than a particular period of time, in here the time gap is set to be 2 seconds
            while ((now - start) <= 2)
            {
                for (int i = 0; i < nrows*ncols; i++)
                {
                    if (recved[i] == 0)
                    {
                        int flag = 0;
                        MPI_Iprobe(i + 1, iter, MPI_COMM_WORLD, &flag, &status);
                        if (flag == 1)
                        {
                            MPI_Recv(&infos[i], sizeof(infos[i]) / 4, MPI_INT, i + 1, iter, MPI_COMM_WORLD, &status);
                            recved_num[i]++;
                            //recved_time[i] = time((time_t*)NULL);
                            gettimeofday(&recved_time[i], NULL);

                            recved[i] = 1;
                            printf("find warning rank  = %d, iter = %d, temp = %d, count = %d flag = %d\n", infos[i].rank, iter, infos[i].temprature, infos[i].count,flag);
                            fflush(stdout);

                        }


                    }
                }
                now = time((time_t*)NULL);
            }
			
			//increase iteration number by 1
            iter++;
            MPI_Barrier(MPI_COMM_WORLD);
            for (int i = 0; i < nrows * ncols; i++)
            {
                if (recved[i] == 0)
                {
                    int flag = 0;
                    MPI_Iprobe(i + 1, iter, MPI_COMM_WORLD, &flag, &status);
                    if (flag == 1)
                    {
                        MPI_Recv(&infos[i], sizeof(infos[i]) / 4, MPI_INT, i + 1, iter, MPI_COMM_WORLD, &status);
                        //recved_time[i] = time((time_t*)NULL);
                        gettimeofday(&recved_time[i], NULL);
                        recved_num[i]++;
                        recved[i] = 1;
                        printf("find warning rank  = %d, iter = %d, temp = %d, count = %d flag = %d\n", infos[i].rank, iter, infos[i].temprature, infos[i].count, flag);
                        fflush(stdout);
                    }


                }
            }
			//write results to log file
            for (int i = 0; i < nrows * ncols; i++)
            {
                if (recved[i] == 1)
                {
                    write_log(infos[i], log_file, iter, recved_num[i], Infrared_value[i], Infrared_time[i], recved_time[i] );
                }
            }
            free(infos);
            //free(recved_time);
            //free(recved);
            free(recved_num);

        }

    }
    printf("process exit!\n");
    fflush(stdout);
    return 0;
}
