
TO COMPILE:

mpicc fit3143_group11_A2_code.c -np fit3143_group11_A2_codeout


TO RUN:

mpirun -np X fit3143_group11_A2_codeout Y Z

WHERE Y * Z =  X - 1